# space-hazard-project
Trabalho A3 da unidade curricular de computação gráfica e realidade virtual

# Tecnologias utilizadas
- Python
- Pygame

# Como utilizar
- Instale o Python na sua máquina
- Abra o terminal na pasta do projeto e digite "python main.py"
